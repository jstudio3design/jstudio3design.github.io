Esta obra está protegida pela Lei Federal nº 9.610/1998,
na República Federativa do Brasil. 
--------------------------------------------------------
Trailblazer PMESP 2023/2024 | Low-Poly SA Style
Author: Lucas Eduardo
Edição PMESP 2023: J0hnn1e20
--------------------------------------------------------
Confira a Traiblazer usada como base para este projeto aqui:
https://www.vulpercommunity.com.br/2024/11/gta-sa-trailblazer-2021-civil.html
--------------------------------------------------------
Esta modificação utiliza funcionalidades do mod VSL para
PC. Adquira-o aqui:
https://github.com/Danilo1301/giroflex-vsl-pc