2025 | J0hnn1e20's Warehouse
--------------------------------------------------------
Maibatsu Copprio | Low-Poly SA Style
Author: Gorunic
--------------------------------------------------------
O Autor autorizou a publicação no blog J0hnn1e20's 
Warehouse. Para quaisquer dúvidas específicas, obter uma 
permissão para publicação em outros meios,
contatar o autor.

https://j0hnn1e20.github.io