Esta obra está protegida pela Lei Federal nº 9.610/1998,
Lei de Direitos Autorais, a qual regula os direitos 
relativos à criação intelectual, como obras artísticas
na República Federativa do Brasil. 
--------------------------------------------------------
Ingram Mac-10
Autor: J0hnn1e20
--------------------------------------------------------
Mova a pasta "Ingram Mac-10" para a pasta do modloader.
Substitui: Micro Uzi
--------------------------------------------------------
Esta obra está classificada como Obra de Livre Uso.

Por favor, consulte os Termos de Uso disponíveis no link
abaixo para conhecer as permissões e restrições 
relacionadas ao uso desta obra:  

https://j0hnn1e20.github.io/page/EULA.html