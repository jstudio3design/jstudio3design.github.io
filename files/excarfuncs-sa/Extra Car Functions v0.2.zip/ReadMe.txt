[PORTUGUÊS]----------------------------------------------------------

Extra Car Functions [ALPHA v0.2]
Autor: Johnnie
Agradecimentos ao Caio Sant'Ana e OrionSJ

Ao usar em seus projetos, matenha créditos ao autor.

Todos os comandos podem ser alterados no ini do mod.

Comandos:

T = Liga/Desliga motor.
L = Trava/Destrava portas do veículo.
1 = Abre/Fecha porta-malas do veículo.
2 = Abre/Fecha vidro da porta do motorista. (A Mudança é muito brusca, não há uma animação exata, e é feito pra ser compatível com os veículos originais do jogo).
J = Liga/Desliga faróis.

Este trabalho está licenciado sob CC BY-SA 4.0


[ENGLISH]----------------------------------------------------------


Extra Car Functions [ALPHA v0.2]
Author: Johnnie
Thanks to Caio Sant'Ana and OrionSJ

When using in your projects, keep credits to the author.

All commands can be changed in the mod ini.

Commands:

T = Motor on/off.
L = Locks/Unlocks vehicle doors.
1 = Opens/Closes the vehicle’s trunk.
2 = Opens/Closes the driver’s door window. (The change is very abrupt, there is no exact animation, and it is made to be compatible with the game's original vehicles).
J = Turns on/off headlights.

This work is licensed under CC BY-SA 4.0