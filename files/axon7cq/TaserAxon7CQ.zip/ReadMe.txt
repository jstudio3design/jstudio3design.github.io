Esta obra está protegida pela Lei Federal nº 9.610/1998,
na República Federativa do Brasil. 
--------------------------------------------------------
Axon Taser 7 CQ
Author: J0hnn1e20
--------------------------------------------------------
Esta obra está classificada como Obra de Livre Uso.

Por favor, consulte os Termos de Uso disponíveis no link
abaixo para conhecer as permissões e restrições 
relacionadas ao uso desta obra:  

https://j0hnn1e20.github.io/page/EULA.html